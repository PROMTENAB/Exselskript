Attribute VB_Name = "Inventering_Rapportautomatik"
Option Explicit

' INVENTERING | Vectorworks Excel-export -> rapport
' Importera modulen i Excel VBA (Alt+F11 > Arkiv > Importera fil).
' Spara arbetsboken som .xlsm. K�r InstalleraKnappar en g�ng.
' �ndringar f�rs INTE tillbaka till Vectorworks av den h�r modulen.
' M�ngder och sparprocent i befintliga rapportposter f�ljer R�data automatiskt.
' Kategorier, nya littera och utf�llbara objekt uppdateras med UppdateraRapporter.
' Rapportmall innehaller alla grundformat och kolumnbredder for genererade rapporter.

Private Const SHEET_RAW As String = "R�data"
Private Const SHEET_RULES As String = "Regler"
Private Const SHEET_PREF As String = "Rapportval"
Private Const SHEET_SUM As String = "Sammanst�llning"
Private Const GENERATED_PREFIX As String = "OMR - "
Private Const LIVE_LAST_ROW As Long = 2000
Private mOutput() As Variant, mFormula() As Boolean, mRowType() As Long
Private mRaw As Variant, mRules As Variant
Private mPhotoJobs As Collection
Private mRulesByRow As Object, mUnits() As String
Private mHeadingOrder As Object
Private mUseConditionRules As Boolean
Private mRawLast As Long
Private mOmitLit As String, mOmitMaterial As String
Private mTemplateStyles(1 To 14, 1 To 12) As String

Public Sub InstalleraKnappar()
    Dim ws As Worksheet, S As Shape, i As Long
    Set ws = ThisWorkbook.Worksheets(SHEET_PREF)
    For i = ws.Shapes.count To 1 Step -1
        If Left$(ws.Shapes(i).name, Len("InventeringBtn_")) = "InventeringBtn_" Then ws.Shapes(i).Delete
    Next i
    Set S = ws.Shapes.AddShape(5, ws.Range("H4").Left, ws.Range("H4").Top, 205, 36)
    With S
        .name = "InventeringBtn_Import"
        .TextFrame.Characters.text = "1   Importera fr�n Vectorworks"
        .OnAction = "ImporteraFranVectorworks"
        .Fill.ForeColor.RGB = RGB(25, 50, 76)
        .Line.Visible = 0
        .TextFrame.Characters.Font.Color = RGB(255, 255, 255)
    End With
    Set S = ws.Shapes.AddShape(5, ws.Range("H7").Left, ws.Range("H7").Top, 205, 36)
    With S
        .name = "InventeringBtn_Rapporter"
        .TextFrame.Characters.text = "2   Uppdatera rapporter"
        .OnAction = "UppdateraRapporter"
        .Fill.ForeColor.RGB = RGB(23, 110, 116)
        .Line.Visible = 0
        .TextFrame.Characters.Font.Color = RGB(255, 255, 255)
    End With
    ws.Range("H:H").ColumnWidth = 28
    MsgBox "Tv� knappar har skapats i fliken Rapportval.", vbInformation
End Sub

Private Function LastRowIn(ByVal ws As Worksheet, ByVal col As Long) As Long
    LastRowIn = ws.Cells(ws.rows.count, col).End(xlUp).Row
End Function

Private Function S(ByVal v As Variant) As String
    If IsError(v) Or IsNull(v) Or IsEmpty(v) Then
        S = ""
    Else
        S = Trim$(CStr(v))
    End If
End Function

Private Function N(ByVal v As Variant) As Double
    If IsNumeric(v) Then N = CDbl(v) Else N = 0#
End Function

Private Function IsYes(ByVal value As Variant) As Boolean
    IsYes = (StrComp(S(value), "Ja", vbTextCompare) = 0)
End Function

Private Function Excluded(ByVal ws As Worksheet, ByVal rowNo As Long) As Boolean
    Dim omitLit As String, omitMaterial As String
    omitLit = mOmitLit
    omitMaterial = mOmitMaterial
    Excluded = False
    If Len(omitLit) > 0 Then
        If InStr(1, S(mRaw(rowNo, 1)), omitLit, vbTextCompare) > 0 Then Excluded = True
    End If
    If Len(omitMaterial) > 0 Then
        If StrComp(S(mRaw(rowNo, 2)), omitMaterial, vbTextCompare) = 0 Then Excluded = True
    End If
End Function

Private Function ImagePath(ByVal imageName As String) As String
    Dim base As String
    If Len(imageName) = 0 Then Exit Function
    If InStr(1, imageName, ":") > 0 Or Left$(imageName, 2) = "\\" Then
        ImagePath = imageName
        Exit Function
    End If
    base = S(ThisWorkbook.Worksheets(SHEET_PREF).Range("B11").Value2)
    If Len(base) = 0 Then Exit Function
    If Right$(base, 1) <> "\" And Right$(base, 1) <> "/" Then base = base & "\"
    ImagePath = base & imageName
End Function

Private Function GetRule(ByVal material As String, ByVal className As String, _
                         ByVal lit As String, ByVal area As String, ByVal condition As String) As Variant
    Dim ws As Worksheet, r As Long, last As Long, bestRow As Long
    Dim bestScore As Double, score As Double, fieldVal As String
    Dim fieldName As String, needle As String, localArea As String
    Set ws = ThisWorkbook.Worksheets(SHEET_RULES)
    last = UBound(mRules, 1)
    bestScore = -1E+30
    For r = 5 To last
        If IsYes(mRules(r, 2)) Then
            fieldName = S(mRules(r, 3))
            needle = S(mRules(r, 4))
            localArea = S(mRules(r, 5))
            If Len(localArea) = 0 Or StrComp(localArea, area, vbTextCompare) = 0 Then
                Select Case UCase$(fieldName)
                    Case "MATERIALTYP": fieldVal = material
                    Case "CLASS": fieldVal = className
                    Case "LITTRERING": fieldVal = lit
                    Case "SKICK": fieldVal = condition
                    Case Else: fieldVal = ""
                End Select
                If Len(needle) = 0 Or InStr(1, fieldVal, needle, vbTextCompare) > 0 Then
                    score = N(mRules(r, 1))
                    If Len(localArea) > 0 Then score = score + 1000000#
                    If score > bestScore Then bestScore = score: bestRow = r
                End If
            End If
        End If
    Next r
    If bestRow = 0 Then
        GetRule = Array("�VRIGT", "OKLASSIFICERAT", "", "Auto", 999, False)
    Else
        GetRule = Array(S(mRules(bestRow, 6)), S(mRules(bestRow, 7)), _
                        S(mRules(bestRow, 8)), S(mRules(bestRow, 9)), _
                        N(mRules(bestRow, 10)), UCase$(S(mRules(bestRow, 3))) = "SKICK")
    End If
End Function

Private Function EquipmentStatus(ByVal value As Variant, ByVal sourceRow As Long) As String
    If Len(S(value)) = 0 Then
        EquipmentStatus = "EJ BED�MT"
    ElseIf Not IsNumeric(value) Then
        Err.Raise vbObjectError + 220, "EquipmentStatus", "Sparas % m�ste vara ett tal mellan 0 och 100 % p� r�datarad " & sourceRow
    ElseIf CDbl(value) < 0 Or CDbl(value) > 1 Then
        Err.Raise vbObjectError + 221, "EquipmentStatus", "Sparas % m�ste ligga mellan 0 och 100 % p� r�datarad " & sourceRow
    ElseIf CDbl(value) = 0 Then
        EquipmentStatus = "KASSERAS"
    Else
        EquipmentStatus = "SPARAS"
    End If
End Function

Private Function EquipmentRank(ByVal title As String) As String
    Select Case UCase$(title)
        Case "SPARAS": EquipmentRank = "1"
        Case "KASSERAS": EquipmentRank = "2"
        Case "EJ BED�MT": EquipmentRank = "3"
        Case Else: EquipmentRank = "4"
    End Select
End Function

Private Function FormulaText(ByVal value As String) As String
    FormulaText = Chr$(34) & Replace(value, Chr$(34), Chr$(34) & Chr$(34)) & Chr$(34)
End Function

Private Function DetectUnit(ByVal ws As Worksheet, ByVal i As Long, ByVal pref As String) As String
    pref = LCase$(S(pref))
    If pref = "m�" Or pref = "lpm" Or pref = "antal" Then
        DetectUnit = pref: Exit Function
    End If
    ' Auto: SMG2 �r linj�rt �ven n�r exporten ocks� inneh�ller en area.
    If StrComp(S(mRaw(i, 1)), "SMG2", vbTextCompare) = 0 Then
        DetectUnit = "lpm": Exit Function
    End If
    ' H�rdgjorda ytor kan ha b�de area och omkrets; m�ngden �r arean.
    If InStr(1, S(mRaw(i, 12)), "H�rdgjort", vbTextCompare) > 0 Then
        DetectUnit = "m�": Exit Function
    End If
    If N(mRaw(i, 11)) <> 0 Then
        DetectUnit = "lpm"
    ElseIf N(mRaw(i, 10)) <> 0 Then
        DetectUnit = "m�"
    Else
        DetectUnit = "antal"
    End If
End Function

Private Function GetReportOption(ByVal area As String) As Variant
    Dim ws As Worksheet, i As Long, last As Long, target As String, found As Long
    Set ws = ThisWorkbook.Worksheets(SHEET_PREF)
    last = LastRowIn(ws, 1)
    If Len(area) = 0 Then target = "ALLA DELOMR�DEN" Else target = "STANDARD DELOMR�DE"
    For i = 21 To last
        If StrComp(S(ws.Cells(i, 1).Value2), target, vbTextCompare) = 0 Then found = i
    Next i
    If Len(area) > 0 Then
        For i = 21 To last
            If StrComp(S(ws.Cells(i, 1).Value2), area, vbTextCompare) = 0 Then found = i
        Next i
    End If
    If found = 0 Then
        GetReportOption = Array(3, False, False, True)
    Else
        GetReportOption = Array(Application.Max(1, Application.Min(3, CLng(N(ws.Cells(found, 2).Value2)))), _
               IsYes(ws.Cells(found, 3).Value2), IsYes(ws.Cells(found, 4).Value2), IsYes(ws.Cells(found, 5).Value2))
    End If
End Function

Private Function SafeSheetName(ByVal area As String, ByVal taken As Object) As String
    Dim invalid As Variant, ch As Variant, root As String, tryName As String, num As Long, suffix As String
    invalid = Array("/", "\", "?", "*", "[", "]", ":")
    root = Trim$(area)
    If Len(root) = 0 Then root = "Utan delomr�de"
    For Each ch In invalid: root = Replace(root, CStr(ch), "_"): Next ch
    root = GENERATED_PREFIX & root
    root = Left$(root, 31)
    tryName = root
    num = 1
    Do While taken.Exists(UCase$(tryName))
        num = num + 1
        suffix = "_" & CStr(num)
        tryName = Left$(root, 31 - Len(suffix)) & suffix
    Loop
    taken(UCase$(tryName)) = True
    SafeSheetName = tryName
End Function

' Gemensam design styrs helt fran de formaterade exempelraderna i Rapportmall.
' Redigera rad 1/2/4/6/8/10/12/14 och kolumnbredder A:L i mallen.
Private Sub PrepareReportData()
    Dim tmpl As Worksheet, ws As Worksheet, sc As Range, tc As Style
    Dim t As Variant, c As Long, edge As Variant, styleName As String
    Dim i As Long, area As String, rule As Variant
    Set ws = ThisWorkbook.Worksheets(SHEET_RAW)
    mRawLast = LastRowIn(ws, 1)
    mRaw = ws.Range("A1:L" & Application.Max(2, mRawLast)).Value2
    Set ws = ThisWorkbook.Worksheets(SHEET_RULES)
    mRules = ws.Range("A1:J" & Application.Max(5, LastRowIn(ws, 1))).Value2
    mUseConditionRules = False
    For i = 5 To UBound(mRules, 1)
        If IsYes(mRules(i, 2)) And UCase$(S(mRules(i, 3))) = "SKICK" Then mUseConditionRules = True
    Next i
    With ThisWorkbook.Worksheets(SHEET_PREF)
        mOmitLit = S(.Range("B6").Value2)
        mOmitMaterial = S(.Range("B7").Value2)
    End With
    Set mRulesByRow = CreateObject("Scripting.Dictionary")
    Set mHeadingOrder = CreateObject("Scripting.Dictionary")
    ReDim mUnits(1 To Application.Max(2, mRawLast))
    Set ws = ThisWorkbook.Worksheets(SHEET_RAW)
    For i = 2 To mRawLast
        area = S(mRaw(i, 3))
        If Len(area) = 0 Then area = "Utan delomr�de"
        rule = GetRule(S(mRaw(i, 2)), S(mRaw(i, 12)), S(mRaw(i, 1)), area, S(mRaw(i, 4)))
        rule(5) = CBool(rule(5)) Or mUseConditionRules
        If UCase$(S(rule(0))) = "UTRUSTNING" Then
            rule(1) = EquipmentStatus(mRaw(i, 6), i)
            rule(2) = S(mRaw(i, 4))
            If Len(rule(2)) = 0 Then rule(2) = "SKICK EJ ANGIVET"
            rule(5) = True
        End If
        mRulesByRow.Add CStr(i), rule
        RememberHeadingOrder rule
        mUnits(i) = DetectUnit(ws, i, CStr(rule(3)))
    Next i
    Set tmpl = ThisWorkbook.Worksheets("Rapportmall")
    For Each t In Array(1, 2, 4, 6, 8, 10, 12, 14)
        For c = 1 To 12
            Set sc = tmpl.Cells(CLng(t), c)
            styleName = "Inventering_Auto_" & t & "_" & c
            Set tc = Nothing
            On Error Resume Next
            Set tc = ThisWorkbook.Styles(styleName)
            On Error GoTo 0
            If tc Is Nothing Then Set tc = ThisWorkbook.Styles.Add(styleName)
            mTemplateStyles(CLng(t), c) = styleName
            tc.IncludeAlignment = True
            tc.IncludeBorder = True
            tc.IncludeFont = True
            tc.IncludeNumber = True
            tc.IncludePatterns = True
            tc.IncludeProtection = True
        tc.NumberFormat = sc.NumberFormat
        tc.HorizontalAlignment = sc.HorizontalAlignment
        tc.VerticalAlignment = sc.VerticalAlignment
        tc.WrapText = sc.WrapText
        tc.Orientation = sc.Orientation
        tc.IndentLevel = sc.IndentLevel
        tc.ShrinkToFit = sc.ShrinkToFit
        tc.Locked = sc.Locked
        tc.FormulaHidden = sc.FormulaHidden
        With tc.Font
            .name = sc.Font.name
            .Size = sc.Font.Size
            .Bold = sc.Font.Bold
            .Italic = sc.Font.Italic
            .Underline = sc.Font.Underline
            .Strikethrough = sc.Font.Strikethrough
            .Color = sc.Font.Color
        End With
        With tc.Interior
            .Color = sc.Interior.Color
            .PatternColor = sc.Interior.PatternColor
            .Pattern = sc.Interior.Pattern
        End With
        For Each edge In Array(xlEdgeLeft, xlEdgeTop, xlEdgeBottom, xlEdgeRight, xlDiagonalDown, xlDiagonalUp)
            With tc.Borders(edge)
                If sc.Borders(edge).LineStyle = xlLineStyleNone Then
                    .LineStyle = xlLineStyleNone
                Else
                    .Weight = sc.Borders(edge).Weight
                    .Color = sc.Borders(edge).Color
                    .LineStyle = sc.Borders(edge).LineStyle
                End If
            End With
        Next edge
        Next c
    Next t
End Sub

Private Sub RememberHeadingOrder(ByVal rule As Variant)
    Dim level As Long, path As String, order As Double
    order = N(rule(4))
    For level = 0 To 2
        path = path & Chr$(30) & UCase$(CStr(rule(level)))
        If Not mHeadingOrder.Exists(path) Then
            mHeadingOrder.Add path, order
        ElseIf order < CDbl(mHeadingOrder(path)) Then
            mHeadingOrder(path) = order
        End If
    Next level
End Sub

Private Function HeadingSortKey(ByVal rule As Variant) As String
    Dim level As Long, path As String, result As String, title As String
    For level = 0 To 2
        title = UCase$(CStr(rule(level)))
        path = path & Chr$(30) & title
        If level = 1 And UCase$(S(rule(0))) = "UTRUSTNING" Then
            result = result & EquipmentRank(title) & "|" & title & "|"
        Else
            result = result & Format$(CDbl(mHeadingOrder(path)), "000000") & "|" & title & "|"
        End If
    Next level
    HeadingSortKey = result
End Function

Private Sub CopyTemplateRow(ByVal dest As Worksheet, ByVal outRow As Long, ByVal templateRow As Long)
    Dim c As Long
    ' Rapportmall �r en formatmall. Exempelv�rden och exempelformler f�r aldrig bli rapportdata.
    mRowType(outRow) = templateRow
    For c = 1 To 12
        mOutput(outRow, c) = Empty
        mFormula(outRow, c) = False
    Next c
End Sub

Private Sub ApplyRowFormats(ByVal ws As Worksheet, ByVal selected As Range, ByVal templateRow As Long)
    Dim c As Long
    For c = 1 To 12
        Intersect(selected, ws.Columns(c)).Style = mTemplateStyles(templateRow, c)
    Next c
    selected.RowHeight = ThisWorkbook.Worksheets("Rapportmall").rows(templateRow).RowHeight
End Sub

Private Sub FlushReport(ByVal ws As Worksheet, ByVal lastRow As Long, ByVal photos As Object)
    Dim block() As Variant, r As Long, c As Long, t As Variant, batch As Range
    Dim count As Long, sc As Range, merged As Range, job As Variant, tick As Double
    Dim tmpl As Worksheet, photoRows As Collection
    Dim firstFormula As Long, k As Long, formulas() As Variant
    tick = Timer
    ReDim block(1 To lastRow, 1 To 12)
    ws.Range("A1").Resize(lastRow, 12).NumberFormat = "General"
    For c = 1 To 12
        Set batch = Nothing
        count = 0
        For r = 1 To lastRow
            If Not mFormula(r, c) Then
                block(r, c) = mOutput(r, c)
                ' Bevara text-ID och littera utan att l�gga till apostrofer i inneh�llet.
                If VarType(block(r, c)) = vbString Then
                    If Len(block(r, c)) > 0 Then
                        If batch Is Nothing Then
                            Set batch = ws.Cells(r, c)
                        Else
                            Set batch = Application.Union(batch, ws.Cells(r, c))
                        End If
                        count = count + 1
                        If count = 50 Then
                            batch.NumberFormat = "@"
                            Set batch = Nothing
                            count = 0
                        End If
                    End If
                End If
            End If
        Next r
        If Not batch Is Nothing Then batch.NumberFormat = "@"
    Next c
    ws.Range("A1").Resize(lastRow, 12).Value2 = block
    ' Skriv endast riktiga formler med Formula, i sammanh�ngande kolumnblock.
    For c = 1 To 12
        r = 1
        Do While r <= lastRow
            If mFormula(r, c) Then
                firstFormula = r
                Do While r <= lastRow
                    If Not mFormula(r, c) Then Exit Do
                    r = r + 1
                Loop
                ReDim formulas(1 To r - firstFormula, 1 To 1)
                For k = firstFormula To r - 1
                    formulas(k - firstFormula + 1, 1) = mOutput(k, c)
                Next k
                With ws.Cells(firstFormula, c).Resize(r - firstFormula, 1)
                    .NumberFormat = "General"
                    .Formula = formulas
                    If IsNull(.HasFormula) Then Err.Raise vbObjectError + 211, "FlushReport", "Alla rapportformler kunde inte skrivas."
                    If Not .HasFormula Then Err.Raise vbObjectError + 212, "FlushReport", "Rapportformler blev text."
                End With
            Else
                r = r + 1
            End If
        Loop
    Next c
    LoggaTid "  Blockskrivning", tick
    Set tmpl = ThisWorkbook.Worksheets("Rapportmall")
    For Each t In Array(1, 2, 4, 6, 8, 10, 12, 14)
        Set batch = Nothing
        count = 0
        For r = 1 To lastRow
            If mRowType(r) = CLng(t) Then
                If batch Is Nothing Then
                    Set batch = ws.Range("A" & r & ":L" & r)
                Else
                    Set batch = Application.Union(batch, ws.Range("A" & r & ":L" & r))
                End If
                count = count + 1
                If count = 50 Then
                    ApplyRowFormats ws, batch, CLng(t)
                    Set batch = Nothing
                    count = 0
                End If
            End If
        Next r
        If Not batch Is Nothing Then ApplyRowFormats ws, batch, CLng(t)
        For c = 1 To 12
            Set sc = tmpl.Cells(CLng(t), c)
            If sc.MergeCells Then
                Set merged = sc.MergeArea
                If merged.Row = CLng(t) And merged.Column = c And merged.rows.count = 1 _
                   And c + merged.Columns.count - 1 <= 12 Then
                    For r = 1 To lastRow
                        If mRowType(r) = CLng(t) Then ws.Cells(r, c).Resize(1, merged.Columns.count).Merge
                    Next r
                End If
            End If
        Next c
    Next t
    LoggaTid "  Formatering", tick
    For Each job In mPhotoJobs
        Set photoRows = job(1)
        PutPhotoLink ws.Cells(CLng(job(0)), 10), photoRows, photos
    Next job
    LoggaTid "  Bildl�nkar", tick
End Sub

Private Sub QueuePhoto(ByVal rowNo As Long, ByVal rows As Collection)
    mPhotoJobs.Add Array(rowNo, rows)
End Sub

Private Sub PaintTitle(ByVal ws As Worksheet, ByVal area As String)
    Dim tmpl As Worksheet, c As Long, headers As Variant
    On Error Resume Next
    Set tmpl = ThisWorkbook.Worksheets("Rapportmall")
    On Error GoTo 0
    If tmpl Is Nothing Then Err.Raise vbObjectError + 210, "PaintTitle", "Fliken Rapportmall saknas. Importera den nya Excelmallen innan du kor VBA-modulen."
    For c = 1 To 12
        ws.Columns(c).ColumnWidth = tmpl.Columns(c).ColumnWidth
    Next c
    CopyTemplateRow ws, 1, 1
    CopyTemplateRow ws, 2, 2
    CopyTemplateRow ws, 4, 4
    If Len(area) = 0 Then
        mFormula(1, 1) = False: mOutput(1, 1) = "INVENTERING  /  ALLA DELOMR�DEN"
    Else
        mFormula(1, 1) = False: mOutput(1, 1) = "INVENTERING  /  " & UCase$(area)
    End If
    mFormula(2, 1) = False: mOutput(2, 1) = "LEVANDE M�NGDER  �  Materialinventering / m�ngder och �terbruk"
    headers = Array("LITTRERING", "MATERIALTYP", "m�", "lpm", "Antal", _
       "Sparas %", "Sparas m�ngd", "SKICK", "KOMMENTAR", "BILDER", "DELOMR�DE", "INFO-ID-REFERENS")
    For c = 1 To 12
        mOutput(4, c) = headers(c - 1)
        mFormula(4, c) = False
    Next c
    ws.Outline.summaryRow = xlAbove
    With ws.PageSetup
        .Orientation = xlLandscape
        .PaperSize = xlPaperA3
        .Zoom = False
        .FitToPagesWide = 1
        .FitToPagesTall = False
        .PrintTitleRows = "$1:$4"
        .LeftMargin = Application.CentimetersToPoints(0.7)
        .RightMargin = Application.CentimetersToPoints(0.7)
        .TopMargin = Application.CentimetersToPoints(0.9)
        .BottomMargin = Application.CentimetersToPoints(0.9)
        .CenterFooter = "&P / &N"
    End With
End Sub

Private Sub CategoryHeading(ByVal ws As Worksheet, ByVal rowNo As Long, _
                            ByVal title As String, ByVal level As Long)
    If Len(title) = 0 Then Exit Sub
    CopyTemplateRow ws, rowNo, 4 + 2 * level
    mFormula(rowNo, 1) = False: mOutput(rowNo, 1) = UCase$(title)
End Sub

Private Sub SortKeys(ByRef arr As Variant, ByVal keyStrings As Object, _
                     ByVal first As Long, ByVal last As Long)
    Dim i As Long, j As Long, pivot As String, temp As Variant
    i = first: j = last
    pivot = CStr(keyStrings(arr((first + last) \ 2)))
    Do While i <= j
        Do While StrComp(CStr(keyStrings(arr(i))), pivot, vbTextCompare) < 0: i = i + 1: Loop
        Do While StrComp(CStr(keyStrings(arr(j))), pivot, vbTextCompare) > 0: j = j - 1: Loop
        If i <= j Then
            temp = arr(i): arr(i) = arr(j): arr(j) = temp
            i = i + 1: j = j - 1
        End If
    Loop
    If first < j Then SortKeys arr, keyStrings, first, j
    If i < last Then SortKeys arr, keyStrings, i, last
End Sub

Private Function RoundedQuantity(ByVal nValue As Double, ByVal unit As String) As Double
    Dim stepValue As Double
    If unit = "lpm" Then
        stepValue = N(ThisWorkbook.Worksheets(SHEET_PREF).Range("B13").Value2)
    ElseIf unit = "m�" Then
        stepValue = N(ThisWorkbook.Worksheets(SHEET_PREF).Range("B14").Value2)
    End If
    If stepValue > 0 Then
        RoundedQuantity = Int(nValue / stepValue + 0.5) * stepValue
    Else
        RoundedQuantity = nValue
    End If
End Function


' LEVANDE RAPPORTFORMEL: summera utan att VBA beh�ver k�ras efter m�ngd�ndringar.
' Rader med samma littera/material och samma ursprungliga CLASS + DELOMR�DE ing�r
' direkt, �ven n�r ytterligare objekt tillkommer. Klassificering och nya grupper
' uppdateras d�remot f�rst vid knapptryckning.
Private Function XlText(ByVal value As String) As String
    Dim v As String
    v = Replace(value, "~", "~~")
    v = Replace(v, "*", "~*")
    v = Replace(v, "?", "~?")
    XlText = Chr$(34) & Replace(v, Chr$(34), Chr$(34) & Chr$(34)) & Chr$(34)
End Function

Private Function RngRaw(ByVal columnLetter As String) As String
    RngRaw = "'R�data'!$" & columnLetter & "$2:$" & columnLetter & "$" & LIVE_LAST_ROW
End Function

Private Function FindByID(ByVal rawCol As String, ByVal outRow As Long) As String
    Dim expr As String
    expr = "INDEX(" & RngRaw(rawCol) & ",MATCH($L" & outRow & "," & RngRaw("H") & ",0))"
    FindByID = "IFERROR(IF(LEN(" & expr & ")=0,""""," & expr & "),"""")"
End Function

Private Function GroupCondition(ByVal sourceRow As Long) As String
    Dim cellRef As String
    ' Samma k�llrad som gruppens kommentar/procent; inget ID-uppslag beh�vs.
    cellRef = "'R�data'!$D$" & sourceRow
    GroupCondition = "IF(LEN(" & cellRef & ")=0,""""," & cellRef & ")"
End Function

Private Function ExactConditionCriteria(ByVal conditionExpr As String) As String
    ' COUNTIFS tolkar annars *, ? och inledande j�mf�relsetecken som villkor.
    ExactConditionCriteria = """=""&SUBSTITUTE(SUBSTITUTE(SUBSTITUTE(" & _
        conditionExpr & ",""~"",""~~""),""*"",""~*""),""?"",""~?"")"
End Function

Private Function GroupTerms(ByVal wsRaw As Worksheet, ByVal rows As Collection, _
                            ByVal outRow As Long, ByVal metric As String, _
                            ByVal unit As String, ByVal splitComment As Boolean, _
                            ByVal splitPercent As Boolean) As String
    Dim seen As Object, v As Variant, rr As Long, key As String
    Dim cls As String, area As String, args As String, product As String
    Dim term As String, result As String, amtCol As String, countArgs As String
    Dim sourceFirst As Long, sourceRule As Variant, status As String, conditionText As String
    Set seen = CreateObject("Scripting.Dictionary")
    sourceFirst = CLng(rows(1))
    sourceRule = mRulesByRow(CStr(sourceFirst))
    If unit = "lpm" Then
        amtCol = "K"
    ElseIf unit = "m�" Then
        amtCol = "J"
    Else
        amtCol = "I"
    End If
    For Each v In rows
        rr = CLng(v)
        cls = S(mRaw(rr, 12))
        area = S(mRaw(rr, 3))
        key = UCase$(cls) & Chr$(30) & UCase$(area)
        If Not seen.Exists(key) Then
            seen.Add key, True
            args = RngRaw("A") & ",$A" & outRow & "," & RngRaw("B") & ",$B" & outRow & _
                "," & RngRaw("C") & "," & XlText(area) & "," & RngRaw("L") & "," & XlText(cls)
            product = "--(" & RngRaw("A") & "=$A" & outRow & ")*--(" & RngRaw("B") & "=$B" & outRow & ")" & _
                "*--(" & RngRaw("C") & "=" & XlText(area) & ")*--(" & RngRaw("L") & "=" & XlText(cls) & ")"
            If CBool(sourceRule(5)) Then
                conditionText = FormulaText(S(mRaw(sourceFirst, 4)))
                args = args & "," & RngRaw("D") & "," & ExactConditionCriteria(conditionText)
                product = product & "*--(" & RngRaw("D") & "=" & conditionText & ")"
            End If
            If UCase$(S(sourceRule(0))) = "UTRUSTNING" Then
                status = CStr(sourceRule(1))
                Select Case status
                    Case "SPARAS"
                        args = args & "," & RngRaw("F") & ","">0"""
                        product = product & "*--(" & RngRaw("F") & ">0)"
                    Case "KASSERAS"
                        args = args & "," & RngRaw("F") & ",0," & RngRaw("F") & ",""<>"""
                        product = product & "*--(" & RngRaw("F") & "=0)*--(LEN(" & RngRaw("F") & ")>0)"
                    Case "EJ BED�MT"
                        args = args & "," & RngRaw("F") & ","""""
                        product = product & "*--(LEN(" & RngRaw("F") & ")=0)"
                End Select
            End If
            If splitComment Then
                args = args & "," & RngRaw("E") & ",'R�data'!$E$" & sourceFirst
                product = product & "*--(" & RngRaw("E") & "='R�data'!$E$" & sourceFirst & ")"
            End If
            If splitPercent Then
                args = args & "," & RngRaw("F") & ",'R�data'!$F$" & sourceFirst
                product = product & "*--(" & RngRaw("F") & "='R�data'!$F$" & sourceFirst & ")"
            End If
            Select Case metric
                Case "QTY"
                    term = "SUMIFS(" & RngRaw(amtCol) & "," & args & ")"
                Case "COUNT"
                    term = "COUNTIFS(" & args & ")"
                Case "MISSING"
                    term = "COUNTIFS(" & args & "," & RngRaw("F") & "," & Chr$(34) & Chr$(34) & ")"
                Case "SAVED"
                    term = "SUMPRODUCT(" & product & "*" & RngRaw(amtCol) & "*" & RngRaw("F") & ")"
                Case "CONDITION"
                    term = "COUNTIFS(" & args & "," & RngRaw("D") & "," & ExactConditionCriteria(GroupCondition(sourceFirst)) & ")"
                Case Else
                    term = "0"
            End Select
            If Len(result) > 0 Then result = result & "+"
            result = result & term
        End If
    Next v
    If Len(result) = 0 Then result = "0"
    GroupTerms = "(" & result & ")"
End Function

Private Sub LiveReportGroup(ByVal ws As Worksheet, ByVal wsRaw As Worksheet, _
                            ByVal headerRow As Long, ByVal rows As Collection, _
                            ByVal lastDetail As Long, ByVal unit As String, _
                            ByVal splitComment As Boolean, ByVal splitPercent As Boolean)
    Dim qty As String, saveQty As String, countAll As String, missing As String
    Dim sameCondition As String, stepCell As String, rowIx As Long
    Dim rawFirstID As String, mainCol As Long
    qty = GroupTerms(wsRaw, rows, headerRow, "QTY", unit, splitComment, splitPercent)
    saveQty = GroupTerms(wsRaw, rows, headerRow, "SAVED", unit, splitComment, splitPercent)
    countAll = GroupTerms(wsRaw, rows, headerRow, "COUNT", unit, splitComment, splitPercent)
    missing = GroupTerms(wsRaw, rows, headerRow, "MISSING", unit, splitComment, splitPercent)
    sameCondition = GroupTerms(wsRaw, rows, headerRow, "CONDITION", unit, splitComment, splitPercent)
    rawFirstID = S(mRaw(CLng(rows(1)), 8))
    If unit = "lpm" Then
        mainCol = 4
        stepCell = "'Rapportval'!$B$13"
    ElseIf unit = "m�" Then
        mainCol = 3
        stepCell = "'Rapportval'!$B$14"
    Else
        mainCol = 5
        stepCell = "0"
    End If
    mFormula(headerRow, mainCol) = True: mOutput(headerRow, mainCol) = "=IF(" & countAll & "=0,"""",IF(" & stepCell & _
         ">0,ROUND(" & qty & "/" & stepCell & ",0)*" & stepCell & "," & qty & "))"
    mFormula(headerRow, 6) = True: mOutput(headerRow, 6) = "=IF(OR(" & qty & "=0," & missing & ">0),""""," & saveQty & "/" & qty & ")"
    mFormula(headerRow, 7) = True: mOutput(headerRow, 7) = "=IF(OR(" & qty & "=0," & missing & ">0),"""",IF(" & stepCell & _
         ">0,ROUND(" & saveQty & "/" & stepCell & ",0)*" & stepCell & "," & saveQty & "))"
    ' Villkorskolumnen reagerar ocks� om objektens skick �ndras.
    mFormula(headerRow, 8) = True: mOutput(headerRow, 8) = "=IF(" & countAll & "=0,"""",IF(" & sameCondition & "=" & countAll & _
          "," & GroupCondition(CLng(rows(1))) & ",""Varierande""))"
    If rows.count > 1 Then
        mFormula(headerRow, 9) = True: mOutput(headerRow, 9) = "=" & countAll & "&"" objekt � �ppna (+)"""
    Else
        mFormula(headerRow, 9) = True: mOutput(headerRow, 9) = "=IF(" & countAll & ">1," & countAll & _
            "&"" objekt � uppdatera f�r nya rader""," & FindByID("E", headerRow) & ")"
    End If
    If rows.count = 1 Then
        mFormula(headerRow, 11) = True: mOutput(headerRow, 11) = "=" & FindByID("C", headerRow)
    End If
    ' L�nk till r�data via ID f�r redan genererade enskilda objektrader.
    If rows.count = 1 Then
        rawFirstID = S(mRaw(CLng(rows(1)), 8))
        mFormula(headerRow, 12) = False: mOutput(headerRow, 12) = mRaw(CLng(rows(1)), 8)
        mFormula(headerRow, 2) = True: mOutput(headerRow, 2) = "=" & FindByID("B", headerRow)
    Else
        For rowIx = headerRow + 1 To lastDetail
            mFormula(rowIx, 1) = True: mOutput(rowIx, 1) = "=IF(" & FindByID("A", rowIx) & "="""","""",""  � ""&" & FindByID("A", rowIx) & ")"
            mFormula(rowIx, 2) = True: mOutput(rowIx, 2) = "=" & FindByID("B", rowIx)
            mFormula(rowIx, 3) = True: mOutput(rowIx, 3) = "=" & FindByID("J", rowIx)
            mFormula(rowIx, 4) = True: mOutput(rowIx, 4) = "=" & FindByID("K", rowIx)
            mFormula(rowIx, 5) = True: mOutput(rowIx, 5) = "=" & FindByID("I", rowIx)
            mFormula(rowIx, 6) = True: mOutput(rowIx, 6) = "=" & FindByID("F", rowIx)
            mFormula(rowIx, 7) = True: mOutput(rowIx, 7) = "=IF(ISNUMBER(F" & rowIx & "),SUM(C" & rowIx & ":E" & rowIx & ")*F" & rowIx & ","""")"
            mFormula(rowIx, 8) = True: mOutput(rowIx, 8) = "=" & FindByID("D", rowIx)
            mFormula(rowIx, 9) = True: mOutput(rowIx, 9) = "=" & FindByID("E", rowIx)
            mFormula(rowIx, 11) = True: mOutput(rowIx, 11) = "=" & FindByID("C", rowIx)
        Next rowIx
    End If
End Sub

Private Function PhotoNames(ByVal text As String, ByVal re As Object) As Collection
    Dim result As New Collection, seen As Object, matches As Object
    Dim m As Object, part As Variant, filename As String
    Set seen = CreateObject("Scripting.Dictionary")
    seen.CompareMode = vbTextCompare
    Set matches = re.Execute(text)
    If matches.count > 0 Then
        For Each m In matches
            filename = Trim$(CStr(m.SubMatches(0)))
            If Len(filename) > 0 Then
                If Not seen.Exists(filename) Then
                    seen.Add filename, True
                    result.Add filename
                End If
            End If
        Next m
    Else
        For Each part In Split(text, ",")
            filename = Trim$(CStr(part))
            If Len(filename) > 0 Then
                If Not seen.Exists(filename) Then
                    seen.Add filename, True
                    result.Add filename
                End If
            End If
        Next part
    End If
    Set PhotoNames = result
End Function

Private Sub BuildPhotoLookup(ByRef photos As Object)
    Dim raw As Worksheet, re As Object, names As Collection
    Dim data As Variant, i As Long, last As Long
    Set photos = CreateObject("Scripting.Dictionary")
    Set raw = ThisWorkbook.Worksheets(SHEET_RAW)
    last = LastRowIn(raw, 1)
    If last < 2 Then Exit Sub
    Set re = CreateObject("VBScript.RegExp")
    re.Pattern = "FOTO\s*\(([^)]*)\)"
    re.Global = True
    re.IgnoreCase = True
    ' L�s en hel kolumn en g�ng; rad 1 inkluderas s� att �ven ett objekt ger en array.
    data = raw.Range("G1:G" & last).Value2
    For i = 2 To last
        Set names = PhotoNames(S(data(i, 1)), re)
        If names.count > 0 Then photos.Add CStr(i), names
    Next i
End Sub

Private Sub PutPhotoLink(ByVal target As Range, ByVal rows As Collection, _
                         ByVal photos As Object)
    Dim v As Variant, filename As Variant, names As Collection
    Dim seen As Object, firstName As String, path As String, label As String
    Set seen = CreateObject("Scripting.Dictionary")
    seen.CompareMode = vbTextCompare
    For Each v In rows
        If photos.Exists(CStr(v)) Then
            Set names = photos(CStr(v))
            For Each filename In names
                If Not seen.Exists(CStr(filename)) Then
                    seen.Add CStr(filename), True
                    If Len(firstName) = 0 Then firstName = CStr(filename)
                End If
            Next filename
        End If
    Next v
    If seen.count = 0 Then Exit Sub
    label = firstName & " (" & seen.count & " bilder)"
    If seen.count = 1 Then label = firstName & " (1 bild)"
    path = ImagePath(firstName)
    If Len(path) = 0 Then
        target.value = label & " - ange fotomapp i Rapportval!B11"
    Else
        target.Worksheet.Hyperlinks.Add Anchor:=target, Address:=path, TextToDisplay:=label
    End If
End Sub


Private Sub RenderReport(ByVal outputSheet As Worksheet, ByVal areaFilter As String, _
                         ByVal photos As Object)
    Dim raw As Worksheet, optionRow As Variant, rule As Variant
    Dim levels As Long, separateComments As Boolean, separatePct As Boolean, showImages As Boolean
    Dim groups As Object, details As Object, totals As Object, saved As Object, missing As Object
    Dim meta As Object, sortValues As Object, groupKey As String, unit As String, arr As Variant
    Dim i As Long, pos As Long, startDetail As Long, lastDetail As Long
    Dim amount As Double, pct As Double, lit As String, mat As String, area As String
    Dim valComment As String, condition As String, key As Variant, keys As Variant
    Dim rows As Collection, detailsRow As Variant, info As Variant
    Dim l1 As String, l2 As String, l3 As String, prev1 As String, prev2 As String, prev3 As String
    Dim prevGroup As String, nRecords As Long, rawRow As Long, rawAmount As Double, rawPct As Double
    Dim rowNo As Long, startRow As Long, sameCondition As Boolean, firstCondition As String, checkRow As Variant
    Dim singleRow As Collection, summaryRow As Long
    Dim buildTick As Double
    buildTick = Timer
    ReDim mOutput(1 To 5 * Application.Max(2, mRawLast) + 10, 1 To 12)
    ReDim mFormula(1 To UBound(mOutput, 1), 1 To 12)
    ReDim mRowType(1 To UBound(mOutput, 1))
    Set mPhotoJobs = New Collection
    Set raw = ThisWorkbook.Worksheets(SHEET_RAW)
    optionRow = GetReportOption(areaFilter)
    levels = CLng(optionRow(0))
    separateComments = CBool(optionRow(1))
    separatePct = CBool(optionRow(2))
    showImages = CBool(optionRow(3))
    Set groups = CreateObject("Scripting.Dictionary")
    Set totals = CreateObject("Scripting.Dictionary")
    Set saved = CreateObject("Scripting.Dictionary")
    Set missing = CreateObject("Scripting.Dictionary")
    Set meta = CreateObject("Scripting.Dictionary")
    Set sortValues = CreateObject("Scripting.Dictionary")
    PaintTitle outputSheet, areaFilter
    For i = 2 To mRawLast
        area = S(mRaw(i, 3))
        If Len(area) = 0 Then area = "Utan delomr�de"
        If Len(areaFilter) = 0 Or StrComp(area, areaFilter, vbTextCompare) = 0 Then
            If Not Excluded(raw, i) Then
                lit = S(mRaw(i, 1))
                mat = S(mRaw(i, 2))
                condition = S(mRaw(i, 4))
                valComment = S(mRaw(i, 5))
                rule = mRulesByRow(CStr(i))
                unit = mUnits(i)
                Select Case unit
                    Case "lpm": amount = N(mRaw(i, 11))
                    Case "m�": amount = N(mRaw(i, 10))
                    Case Else: amount = N(mRaw(i, 9))
                End Select
                groupKey = CStr(rule(0)) & Chr$(30) & CStr(rule(1)) & Chr$(30) & CStr(rule(2)) & Chr$(30) _
                    & lit & Chr$(30) & mat & Chr$(30) & unit
                If CBool(rule(5)) Then groupKey = groupKey & Chr$(30) & S(mRaw(i, 4))
                If separateComments Then groupKey = groupKey & Chr$(30) & valComment
                If separatePct Then groupKey = groupKey & Chr$(30) & S(mRaw(i, 6))
                If Not groups.Exists(groupKey) Then
                    Set rows = New Collection
                    groups.Add groupKey, rows
                    totals.Add groupKey, 0#
                    saved.Add groupKey, 0#
                    missing.Add groupKey, 0&
                    meta.Add groupKey, Array(CStr(rule(0)), CStr(rule(1)), CStr(rule(2)), lit, mat, unit, condition, area)
                    sortValues.Add groupKey, HeadingSortKey(rule) & UCase$(lit) & "|" & _
                       UCase$(mat) & "|" & UCase$(area) & "|" & groupKey
                End If
                Set rows = groups(groupKey)
                rows.Add i
                totals(groupKey) = CDbl(totals(groupKey)) + amount
                If IsNumeric(mRaw(i, 6)) And Len(S(mRaw(i, 6))) > 0 Then
                    pct = CDbl(mRaw(i, 6))
                    saved(groupKey) = CDbl(saved(groupKey)) + amount * pct
                Else
                    missing(groupKey) = CLng(missing(groupKey)) + 1
                End If
            End If
        End If
    Next i
    pos = 5
    If groups.count = 0 Then
        mFormula(pos, 1) = False: mOutput(pos, 1) = "Inga objekt med de valda kriterierna."
        FlushReport outputSheet, pos, photos
        Exit Sub
    End If
    keys = groups.keys
    If groups.count > 1 Then SortKeys keys, sortValues, LBound(keys), UBound(keys)
    prev1 = "": prev2 = "": prev3 = ""
    For Each key In keys
        info = meta(key)
        l1 = CStr(info(0)): l2 = CStr(info(1)): l3 = CStr(info(2))
        If l1 <> prev1 Then
            Debug.Print "  Kategori [" & outputSheet.name & "]: " & l1
            CategoryHeading outputSheet, pos, l1, 1: pos = pos + 1
            prev1 = l1: prev2 = "": prev3 = ""
        End If
        If levels >= 2 Then
            If l2 <> prev2 And Len(l2) > 0 Then
                CategoryHeading outputSheet, pos, l2, 2: pos = pos + 1
                prev2 = l2: prev3 = ""
            End If
        End If
        If levels >= 3 Then
            If l3 <> prev3 And Len(l3) > 0 Then
                CategoryHeading outputSheet, pos, l3, 3: pos = pos + 1
                prev3 = l3
            End If
        End If
        Set rows = groups(key)
        nRecords = rows.count
        summaryRow = pos
        CopyTemplateRow outputSheet, pos, 12
        mFormula(pos, 1) = False: mOutput(pos, 1) = CStr(info(3))
        mFormula(pos, 2) = False: mOutput(pos, 2) = CStr(info(4))
        firstCondition = S(mRaw(CLng(rows(1)), 4))
        sameCondition = True
        For Each checkRow In rows
            If StrComp(firstCondition, S(mRaw(CLng(checkRow), 4)), vbTextCompare) <> 0 Then sameCondition = False
        Next checkRow
        If sameCondition Then
            mFormula(pos, 8) = False: mOutput(pos, 8) = firstCondition
        Else
            mFormula(pos, 8) = False: mOutput(pos, 8) = "Varierande"
        End If
        If nRecords = 1 Then
            rawRow = CLng(rows(1))
            mFormula(pos, 9) = False: mOutput(pos, 9) = S(mRaw(rawRow, 5))
            mFormula(pos, 11) = False: mOutput(pos, 11) = S(mRaw(rawRow, 3))
            mFormula(pos, 12) = False: mOutput(pos, 12) = mRaw(rawRow, 8)
        Else
            mFormula(pos, 9) = False: mOutput(pos, 9) = nRecords & " objekt � se detaljrader (+)"
            If Len(areaFilter) > 0 Then mFormula(pos, 11) = False: mOutput(pos, 11) = areaFilter
        End If
        Select Case CStr(info(5))
            Case "m�": mFormula(pos, 3) = False: mOutput(pos, 3) = RoundedQuantity(CDbl(totals(key)), "m�")
            Case "lpm": mFormula(pos, 4) = False: mOutput(pos, 4) = RoundedQuantity(CDbl(totals(key)), "lpm")
            Case Else: mFormula(pos, 5) = False: mOutput(pos, 5) = CDbl(totals(key))
        End Select
        If CDbl(totals(key)) > 0 And CLng(missing(key)) = 0 Then
            mFormula(pos, 6) = False: mOutput(pos, 6) = CDbl(saved(key)) / CDbl(totals(key))
            mFormula(pos, 7) = False: mOutput(pos, 7) = RoundedQuantity(CDbl(saved(key)), CStr(info(5)))
        End If
        If showImages Then QueuePhoto pos, rows
        If nRecords > 1 Then
            startDetail = pos + 1
            For Each detailsRow In rows
                rawRow = CLng(detailsRow)
                pos = pos + 1
                CopyTemplateRow outputSheet, pos, 14
                rawAmount = 0#
                Select Case CStr(info(5))
                    Case "m�"
                        rawAmount = N(mRaw(rawRow, 10))
                        mFormula(pos, 3) = False: mOutput(pos, 3) = rawAmount
                    Case "lpm"
                        rawAmount = N(mRaw(rawRow, 11))
                        mFormula(pos, 4) = False: mOutput(pos, 4) = rawAmount
                    Case Else
                        rawAmount = N(mRaw(rawRow, 9))
                        mFormula(pos, 5) = False: mOutput(pos, 5) = rawAmount
                End Select
                mFormula(pos, 1) = False: mOutput(pos, 1) = "  >> " & S(mRaw(rawRow, 1))
                mFormula(pos, 2) = False: mOutput(pos, 2) = S(mRaw(rawRow, 2))
                mFormula(pos, 8) = False: mOutput(pos, 8) = S(mRaw(rawRow, 4))
                mFormula(pos, 9) = False: mOutput(pos, 9) = S(mRaw(rawRow, 5))
                mFormula(pos, 11) = False: mOutput(pos, 11) = S(mRaw(rawRow, 3))
                mFormula(pos, 12) = False: mOutput(pos, 12) = mRaw(rawRow, 8)
                If IsNumeric(mRaw(rawRow, 6)) And Len(S(mRaw(rawRow, 6))) > 0 Then
                    rawPct = CDbl(mRaw(rawRow, 6))
                    mFormula(pos, 6) = False: mOutput(pos, 6) = rawPct
                    mFormula(pos, 7) = False: mOutput(pos, 7) = rawAmount * rawPct
                End If
                If showImages Then
                    Set singleRow = New Collection
                    singleRow.Add rawRow
                    QueuePhoto pos, singleRow
                End If
            Next detailsRow
            lastDetail = pos
            outputSheet.rows(startDetail & ":" & lastDetail).Group
            outputSheet.rows(startDetail & ":" & lastDetail).Hidden = True
        End If
        ' Beh�ll rubriker/gruppstrukturen statisk men ber�kna m�ngder och detaljer direkt fr�n R�data.
        LiveReportGroup outputSheet, raw, summaryRow, rows, pos, CStr(info(5)), separateComments, separatePct
        pos = pos + 1
    Next key
    LoggaTid "  Gruppering och inneh�ll", buildTick
    FlushReport outputSheet, pos - 1, photos
    With outputSheet
        .Range("A4:L" & pos).VerticalAlignment = xlCenter
        .Range("I5:I" & pos).WrapText = True
        .Range("F5:F" & pos).NumberFormat = "0%"
        .rows("4:4").AutoFilter
        .PageSetup.PrintArea = "$A$1:$K$" & pos - 1
        ' Radh�jder kan visa tidigare dolda rader. F�ll ihop f�rst EFTER all formatering.
        .Outline.ShowLevels RowLevels:=1
    End With
End Sub

Private Sub LoggaTid(ByVal steg As String, ByRef startTid As Double)
    Dim nu As Double, sekunder As Double
    nu = Timer
    sekunder = nu - startTid
    If sekunder < 0 Then sekunder = sekunder + 86400
    Debug.Print steg & ": " & Format$(sekunder, "0.00") & " sek"
    startTid = nu
End Sub

Public Sub UppdateraRapporter()
    Dim oldCalc As XlCalculation, i As Long, areaSheet As Worksheet, ws As Worksheet
    Dim raw As Worksheet, areas As Object, names As Object, photos As Object
    Dim area As Variant, areaValue As String, name As String, generated As Long
    Dim stegTid As Double, totalTid As Double, oldEvents As Boolean
    oldEvents = Application.EnableEvents
    On Error GoTo Failed
    stegTid = Timer
    totalTid = stegTid
    Debug.Print "----- Rapportuppdatering " & Now & " -----"
    Application.StatusBar = "Rapporter: f�rbereder..."
    oldCalc = Application.Calculation
    Application.ScreenUpdating = False
    Application.DisplayAlerts = False
    Application.Calculation = xlCalculationManual
    Application.EnableEvents = False
    PrepareReportData
    Set raw = ThisWorkbook.Worksheets(SHEET_RAW)
    Set areas = CreateObject("Scripting.Dictionary")
    For i = 2 To LastRowIn(raw, 1)
        If Not Excluded(raw, i) Then
            areaValue = S(raw.Cells(i, 3).Value2)
            If Len(areaValue) = 0 Then areaValue = "Utan delomr�de"
            If Not areas.Exists(areaValue) Then areas.Add areaValue, True
        End If
    Next i
    LoggaTid "F�rberedelser", stegTid
    Application.StatusBar = "Rapporter: rensar gamla rapporter..."
    ' Endast tidigare genererade OMR-flikar tas bort. Anv�nd inte detta prefix f�r egna flikar.
    For i = ThisWorkbook.Worksheets.count To 1 Step -1
        Set ws = ThisWorkbook.Worksheets(i)
        If Left$(ws.name, Len(GENERATED_PREFIX)) = GENERATED_PREFIX Then
            If Left$(S(ws.Range("A2").Value2), Len("GENERERAD AUTOMATISKT")) = "GENERERAD AUTOMATISKT" _
               Or Left$(S(ws.Range("A2").Value2), Len("LEVANDE M�NGDER")) = "LEVANDE M�NGDER" Then ws.Delete
        End If
    Next i
    Application.DisplayAlerts = True
    Set ws = ThisWorkbook.Worksheets(SHEET_SUM)
    On Error Resume Next
    ws.UsedRange.ClearOutline
    On Error GoTo Failed
    ws.UsedRange.EntireRow.Hidden = False
    ws.UsedRange.UnMerge
    ws.Cells.Clear
    LoggaTid "Rensa gamla rapporter", stegTid
    Application.StatusBar = "Rapporter: l�ser bildnamn fr�n r�data..."
    BuildPhotoLookup photos
    LoggaTid "Bildreferenser", stegTid
    Application.StatusBar = "Rapporter: bygger sammanst�llning..."
    RenderReport ws, "", photos
    LoggaTid "Bygga sammanst�llning", stegTid
    Set names = CreateObject("Scripting.Dictionary")
    For i = 1 To ThisWorkbook.Worksheets.count
        names(UCase$(ThisWorkbook.Worksheets(i).name)) = True
    Next i
    LoggaTid "F�rbereda delomr�den", stegTid
    For Each area In areas.keys
        Application.StatusBar = "Rapporter: bygger " & CStr(area) & " (" & (generated + 1) & "/" & areas.count & ")..."
        name = SafeSheetName(CStr(area), names)
        Set areaSheet = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
        areaSheet.name = name
        RenderReport areaSheet, CStr(area), photos
        generated = generated + 1
        LoggaTid "Bygga delomr�de " & CStr(area), stegTid
    Next area
    Application.ScreenUpdating = True
    Application.DisplayAlerts = True
    Application.StatusBar = "Rapporter: slutber�knar formler..."
    Application.Calculation = xlCalculationAutomatic
    Application.Calculate
    LoggaTid "Slutber�kning", stegTid
    LoggaTid "TOTALT", totalTid
    Application.EnableEvents = oldEvents
    Application.StatusBar = False
    MsgBox "Rapporter uppdaterade. Sammanst�llning + " & generated & " delomr�desflikar skapades. Klicka p� + f�r objektspecifika detaljer.", vbInformation
    Exit Sub
Failed:
    Application.EnableEvents = oldEvents
    Application.StatusBar = False
    Application.ScreenUpdating = True
    Application.DisplayAlerts = True
    Application.Calculation = oldCalc
    MsgBox "Fel vid rapportgenerering: " & Err.Number & " � " & Err.Description, vbExclamation
End Sub

Private Function ExportHeadersMatch(ByVal ws As Worksheet) As Boolean
    ExportHeadersMatch = (StrComp(S(ws.Cells(1, 1).Value2), "LITTRERING", vbTextCompare) = 0 _
                 And StrComp(S(ws.Cells(1, 8).Value2), "INFO-ID-REFERENS", vbTextCompare) = 0)
End Function

Public Sub ImporteraFranVectorworks()
    Dim dialog As FileDialog, srcWB As Workbook, source As Worksheet, candidate As Worksheet, ws As Worksheet
    Dim ids As Object, visited As Object, rowData As Variant, id As String
    Dim srcRow As Long, targetRow As Long, srcLast As Long, lastTarget As Long
    Dim updated As Long, added As Long, missing As Long, duplicate As Long, col As Long
    Dim keepRatings As Boolean, oldCalc As XlCalculation, lo As ListObject
    Dim name As String, oldVal As String, existing As Boolean
    On Error GoTo Failed
    Set dialog = Application.FileDialog(3)
    With dialog
        .title = "V�lj Excel-export fr�n Vectorworks"
        .Filters.Clear
        .Filters.Add "Excel-filer", "*.xlsx;*.xlsm;*.xls"
        .AllowMultiSelect = False
        If .Show <> -1 Then Exit Sub
        name = .SelectedItems(1)
    End With
    If StrComp(name, ThisWorkbook.FullName, vbTextCompare) = 0 Then
        MsgBox "V�lj exportfilen fr�n Vectorworks, inte sj�lva rapportarbetsboken.", vbExclamation
        Exit Sub
    End If
    oldCalc = Application.Calculation
    Application.ScreenUpdating = False
    Application.Calculation = xlCalculationManual
    Set srcWB = Workbooks.Open(filename:=name, UpdateLinks:=0, ReadOnly:=True)
    For Each candidate In srcWB.Worksheets
        If ExportHeadersMatch(candidate) Then
            Set source = candidate
            Exit For
        End If
    Next candidate
    If source Is Nothing Then
        MsgBox "Hittar inte r�datablad med rubrikerna LITTRERING och INFO-ID-REFERENS i kolumn A respektive H.", vbExclamation
        GoTo SafeEnd
    End If
    Set ws = ThisWorkbook.Worksheets(SHEET_RAW)
    Set ids = CreateObject("Scripting.Dictionary")
    Set visited = CreateObject("Scripting.Dictionary")
    lastTarget = LastRowIn(ws, 1)
    If StrComp(S(ThisWorkbook.Worksheets(SHEET_PREF).Range("B16").Value2), "Radera", vbTextCompare) = 0 Then
        ws.Range("A2:L" & Application.Max(2, lastTarget)).ClearContents
        lastTarget = 1
        ThisWorkbook.Worksheets(SHEET_PREF).Range("B16").value = "Raderade"
    End If
    For targetRow = 2 To lastTarget
        id = UCase$(S(ws.Cells(targetRow, 8).Value2))
        If Len(id) > 0 Then
            If Not ids.Exists(id) Then ids.Add id, targetRow
        End If
    Next targetRow
    keepRatings = IsYes(ThisWorkbook.Worksheets(SHEET_PREF).Range("B5").Value2)
    srcLast = LastRowIn(source, 8)
    For srcRow = 2 To srcLast
        id = UCase$(S(source.Cells(srcRow, 8).Value2))
        If Len(id) = 0 Then
            missing = missing + 1
        ElseIf visited.Exists(id) Then
            duplicate = duplicate + 1
        Else
            visited.Add id, True
            existing = ids.Exists(id)
            If existing Then
                targetRow = CLng(ids(id))
                updated = updated + 1
            Else
                lastTarget = lastTarget + 1
                targetRow = lastTarget
                ids.Add id, targetRow
                added = added + 1
            End If
            For col = 1 To 12
                If keepRatings And existing And (col = 4 Or col = 5 Or col = 6) And _
                   Len(S(ws.Cells(targetRow, col).Value2)) > 0 Then
                    ' Beh�ll redan ifyllt SKICK, KOMMENTAR och ANDELSPARAS.
                Else
                    ws.Cells(targetRow, col).Value2 = source.Cells(srcRow, col).Value2
                End If
            Next col
        End If
    Next srcRow
    On Error Resume Next
    Set lo = ws.ListObjects("tblRadata")
    If Not lo Is Nothing Then lo.Resize ws.Range("A1:L" & Application.Max(2, lastTarget))
    On Error GoTo Failed
    ws.Range("F2:F" & Application.Max(2, lastTarget)).NumberFormat = "0%"
SafeEnd:
    If Not srcWB Is Nothing Then srcWB.Close SaveChanges:=False
    Application.ScreenUpdating = True
    Application.Calculation = oldCalc
    If Not source Is Nothing Then
        UppdateraRapporter
        MsgBox "Import klar. Uppdaterade: " & updated & ". Nya: " & added & _
           ". Saknade ID: " & missing & ". Dubbletter i export: " & duplicate & ".", vbInformation
    End If
    Exit Sub
Failed:
    On Error Resume Next
    If Not srcWB Is Nothing Then srcWB.Close SaveChanges:=False
    Application.ScreenUpdating = True
    Application.Calculation = oldCalc
    MsgBox "Import misslyckades: " & Err.Description, vbExclamation
End Sub

